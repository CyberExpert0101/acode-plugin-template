# BSDK Acode Theme
> about: BSDK Theme is an Acoode app theme Developed by BSDK Developer (Goutam).

GotHub -> https://github.com/CyberExpert0101

## How 2 Use
 ----------- 
  
 - Step1: First install the Plugin .
 - Step2: Open Settings.
 - Step3: Now Click on Theme Option.
 - Step4: aab App Theme saction per dekh "Bsdk Theme" ka ek Option hoga.
 - Step5' us per Click kar de .
 - Step6: Done | Tera Theme Apply ho gaya .
 - Step7: Av tu BSDK Theme Ko Enjoy kar sakta he.

**Note:** Ho sakta he ki tumko ye Theme Pasand na aaye. agar theme Pasand nahi
aaya toh Uninstall kar dena ya fir Theme Change kar lena.
